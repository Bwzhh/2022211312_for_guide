#include<bits/stdc++.h>

int getval(int n){
    return (rand()%n+n)%n;
}
char s[220][205];
int main() {
    freopen("places0.txt","r",stdin);
    freopen("222.txt","w",stdout);
    srand((unsigned)time(0));
    for(int i=0;i<200;++i){
        scanf("%s",s[i]);
    }
    for(int i=68;i<300;++i){
        int x=getval(7);
        if(x==0){
            printf("%d %d %d:%s\n",getval(100),getval(100),i,s[50]);
        }
        else printf("%d %d %d:%s\n",getval(100),getval(100),i,s[getval(30)]);
    }
    for(int i=300;i<500;++i){
        int x=getval(7);
        if(x==0){
            printf("%d %d %d:%s\n",getval(100),getval(100),i,s[50]);
        }
        else printf("%d %d %d:%s\n",getval(100),getval(100),i,s[getval(20)+30]);
    }
    for(int i=166;i<500;++i){
        printf("%d %d %d %d\n",i,i-1,getval(100),0);
    }
    for(int i=68;i<168;++i)
        printf("%d %d %d %d\n",i,i-1,getval(100),0);
    for(int i=600;i<40000;++i){
        printf("%d %d %d %d\n",getval(500),getval(500),getval(100),getval(3));
    }
}
