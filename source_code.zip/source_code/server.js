const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { exec } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

app.post('/login', (req, res) => {
    const { type, username, password } = req.body;

    // 执行 main.exe 程序
    exec(`main.exe ${type} ${username} ${password}`, (error, stdout, stderr) => {
        console.log(`操作类型为${ type }`);
        if (error) {
            console.error('执行 main.exe 程序时出错:', error);
            res.json({ message: '登录失败', success: false });
            return;
        }
        console.log('执行 main.exe 后的输出:', stdout);
        // 根据程序的输出来判断登录是否成功
        if (stdout.includes('登录成功')) {
            res.json({ message: '登录成功', success: true });
        } else {
            res.json({ message: '登录失败', success: false });
        }
    });
});

app.post('/recommendations_1', (req, res) => {
    const { type } = req.body;

    // 执行 C 程序
    exec(`main.exe ${type}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});

app.post('/recommendations_2', (req, res) => {
    const { type ,key} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${key}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});

app.post('/recommendations_3', (req, res) => {
    const { type ,str,key} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${str} ${key}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});

app.post('/places_1', (req, res) => {
    const { type ,str} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${str}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});

app.post('/places_2', (req, res) => {
    const { type ,place1,place2,place3,key} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${place1} ${place2} ${place3} ${key}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});

app.post('/diaries_1', (req, res) => {
    const { type ,key} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${key} `, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            res.send(stdout);
        }
    });
});

app.post('/diaries_2', (req, res) => {
    const { type ,text,opt1,opt2} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${text} ${opt1} ${opt2} `, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            res.send(stdout);
        }
    });
});

app.post('/diaries_3', (req, res) => {
    const { type ,article,num2} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${article} ${num2} `, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            res.send(stdout);
        }
    });
});

app.post('/diaries_4', (req, res) => {
    const { type ,destination,title,article} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${destination} ${title} ${article} `, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            res.json({ message: '录入成功', success: true });
        }
    });
});

app.post('/planning', (req, res) => {
    const { type ,bel,place0,place1,place2,place3,place4,place5,key} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${bel} ${place0} ${place1} ${place2} ${place3} ${place4} ${place5} ${key}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});

app.post('/dish', (req, res) => {
    const { type ,bel0,bel1,key0,key1} = req.body;

    // 执行 C 程序
    exec(`main.exe ${type} ${bel0} ${bel1} ${key0} ${key1}`, (error, stdout, stderr) => {
        console.log('执行 main.exe 后的输出:\n', stdout);
        if (error) {
            console.error('执行 C 程序时出错:', error);
            res.status(500).json({ message: '执行 C 程序时出错', success: false });
        } else {
            // // 将 C 程序的输出按换行符分割成数组，并包装成 JSON 格式发送给前端
            // const outputArray = stdout.split('\n').map(item => ({ value: item.trim() }));
            // res.json({ message: '执行成功', success: true, output: outputArray });
            res.send(stdout);
        }
    });
});


app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
